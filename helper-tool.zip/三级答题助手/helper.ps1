﻿param([string]$SelfTest = '')

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Runtime.WindowsRuntime

Add-Type @"
using System.Runtime.InteropServices;
public class DpiHelper {
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
}
"@
[void][DpiHelper]::SetProcessDPIAware()

$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Storage.StorageFile, Windows.Foundation, ContentType=WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Foundation, ContentType=WindowsRuntime]

function Await($WinRtTask, $ResultType) {
    $asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
        $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
        $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
    })[0]
    $netTask = $asTask.MakeGenericMethod($ResultType).Invoke($null, @($WinRtTask))
    $netTask.Wait(-1) | Out-Null
    $netTask.Result
}

$script:OcrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('zh-Hans-CN'))
if (-not $script:OcrEngine) {
    $script:OcrEngine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
}
if (-not $script:OcrEngine) { throw 'No OCR engine available' }

function Get-OcrText([string]$imagePath) {
    $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($imagePath)) ([Windows.Storage.StorageFile])
    $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $result = Await ($script:OcrEngine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
    $stream.Dispose()
    $lines = @()
    foreach ($line in $result.Lines) { $lines += $line.Text }
    return ($lines -join "`n")
}

function Normalize([string]$s) {
    if (-not $s) { return '' }
    return ($s -replace '[^\p{L}\p{N}]', '')
}

function Get-Bigrams([string]$s) {
    $set = New-Object 'System.Collections.Generic.HashSet[string]'
    for ($i = 0; $i -lt $s.Length - 1; $i++) { [void]$set.Add($s.Substring($i, 2)) }
    return ,$set
}

function Get-Dice($a, $b) {
    if ($a.Count -eq 0 -or $b.Count -eq 0) { return 0 }
    $small = $a; $big = $b
    if ($a.Count -gt $b.Count) { $small = $b; $big = $a }
    $inter = 0
    foreach ($x in $small) { if ($big.Contains($x)) { $inter++ } }
    return (2.0 * $inter) / ($a.Count + $b.Count)
}

$script:BankPath = Join-Path $PSScriptRoot 'bank.json'
$script:Bank = Get-Content $script:BankPath -Raw -Encoding UTF8 | ConvertFrom-Json
$script:Index = New-Object System.Collections.ArrayList
foreach ($item in $script:Bank) {
    $n = Normalize $item.s
    [void]$script:Index.Add([pscustomobject]@{
        N = $n
        BG = (Get-Bigrams $n)
        S = $item.s
        O = $item.o
        A = $item.a
        P = $item.p
    })
}

function Match-One([string]$n) {
    if ($n.Length -lt 6) { return $null }
    $bg = Get-Bigrams $n
    $best = $null
    $bestScore = 0
    foreach ($e in $script:Index) {
        $score = 0
        if ($e.N -eq $n) { $score = 1.0 }
        elseif ($e.N.Length -ge 5 -and ($e.N.Contains($n) -or $n.Contains($e.N))) {
            $ratio = [Math]::Min($e.N.Length, $n.Length) / [Math]::Max($e.N.Length, $n.Length)
            $score = 0.85 + 0.15 * $ratio
        }
        else {
            $score = Get-Dice $bg $e.BG
        }
        if ($score -gt $bestScore) { $bestScore = $score; $best = $e }
    }
    if ($best) { return [pscustomobject]@{ Score = $bestScore; Item = $best } }
    return $null
}

function Find-Answer([string]$text) {
    if (-not $text) { return $null }
    $lines = @($text -split "`r?`n" | ForEach-Object { Normalize $_ } | Where-Object { $_.Length -ge 8 })
    if ($lines.Count -eq 0) { return $null }

    $cands = New-Object System.Collections.ArrayList
    foreach ($l in ($lines | Sort-Object Length -Descending | Select-Object -First 3)) { [void]$cands.Add($l) }
    for ($i = 0; $i -lt $lines.Count - 1; $i++) {
        $j = $lines[$i] + $lines[$i + 1]
        if ($j.Length -ge 12) { [void]$cands.Add($j) }
    }

    $best = $null
    $bestScore = 0
    foreach ($c in $cands) {
        $r = Match-One $c
        if ($r -and $r.Score -gt $bestScore) { $bestScore = $r.Score; $best = $r }
        if ($bestScore -ge 0.99) { break }
    }
    if ($best -and $bestScore -ge 0.55) { return $best }
    return $null
}

function Capture-Region([int]$x, [int]$y, [int]$w, [int]$h) {
    $bmp = New-Object System.Drawing.Bitmap($w, $h)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.CopyFromScreen($x, $y, 0, 0, (New-Object System.Drawing.Size($w, $h)))
    $path = Join-Path $env:TEMP 'zt_answer_helper_capture.png'
    $bmp.Save($path, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose(); $bmp.Dispose()
    return $path
}

# ---------- self test ----------
if ($SelfTest) {
    $t = Get-OcrText $SelfTest
    $hit = Find-Answer $t
    if ($hit) {
        Write-Output ('MATCH: ' + [Math]::Round($hit.Score * 100) + '% | ' + $hit.Item.A)
    } else {
        Write-Output 'MATCH: none'
    }
    exit 0
}

# ---------- config ----------
$script:ConfigPath = Join-Path $PSScriptRoot 'config.json'
$script:Region = $null
if (Test-Path $script:ConfigPath) {
    try {
        $c = Get-Content $script:ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
        $script:Region = @{ X = [int]$c.X; Y = [int]$c.Y; W = [int]$c.W; H = [int]$c.H }
    } catch {}
}
if (-not $script:Region) {
    $b = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
    $w = [int]($b.Width * 0.72)
    $h = [int]($b.Height * 0.5)
    $script:Region = @{
        X = $b.X + [int](($b.Width - $w) / 2)
        Y = $b.Y + [int]($b.Height * 0.18)
        W = $w
        H = $h
    }
}

$script:Paused = $false
$script:Busy = $false
$script:formRef = $null

# ---------- UI ----------
$form = New-Object System.Windows.Forms.Form
$form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
$form.TopMost = $true
$form.Opacity = 0.80
$form.ShowInTaskbar = $false
$form.StartPosition = [System.Windows.Forms.FormStartPosition]::Manual
$wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
$form.Size = New-Object System.Drawing.Size(330, 76)
$form.Location = New-Object System.Drawing.Point(($wa.Right - 348), ($wa.Bottom - 104))
$form.BackColor = [System.Drawing.Color]::FromArgb(27, 29, 33)
$form.ForeColor = [System.Drawing.Color]::White
$script:formRef = $form

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Font = New-Object System.Drawing.Font('Microsoft YaHei', 8)
$lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(96, 100, 108)
$lblStatus.SetBounds(10, 5, 284, 16)
$lblStatus.Text = '识别中'
$form.Controls.Add($lblStatus)

$lblAnswer = New-Object System.Windows.Forms.Label
$lblAnswer.Font = New-Object System.Drawing.Font('Microsoft YaHei', 15, [System.Drawing.FontStyle]::Bold)
$lblAnswer.ForeColor = [System.Drawing.Color]::FromArgb(178, 184, 170)
$lblAnswer.SetBounds(10, 24, 296, 44)
$lblAnswer.Text = '等待识别…'
$form.Controls.Add($lblAnswer)

# 右上角小方框：框选识别区域
$btnSelect = New-Object System.Windows.Forms.Label
$btnSelect.Text = '□'
$btnSelect.Font = New-Object System.Drawing.Font('Microsoft YaHei', 11)
$btnSelect.ForeColor = [System.Drawing.Color]::FromArgb(74, 78, 86)
$btnSelect.TextAlign = 'MiddleCenter'
$btnSelect.SetBounds(300, 3, 22, 20)
$btnSelect.Cursor = [System.Windows.Forms.Cursors]::Hand
$form.Controls.Add($btnSelect)
$btnSelect.Add_MouseEnter({ $btnSelect.ForeColor = [System.Drawing.Color]::FromArgb(128, 132, 140) })
$btnSelect.Add_MouseLeave({ $btnSelect.ForeColor = [System.Drawing.Color]::FromArgb(74, 78, 86) })

$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miSelect = $menu.Items.Add('框选识别区域')
$miPause = $menu.Items.Add('暂停')
$miClose = $menu.Items.Add('退出')
$form.ContextMenuStrip = $menu
$lblStatus.ContextMenuStrip = $menu
$lblAnswer.ContextMenuStrip = $menu

$miClose.Add_Click({ $form.Close() })

# 拖动（窗口与文字都可拖）
$script:dragOffset = $null
foreach ($c in @($form, $lblStatus, $lblAnswer)) {
    $c.Add_MouseDown({
        $script:dragOffset = [System.Windows.Forms.Cursor]::Position
        $script:dragFormLoc = $script:formRef.Location
    })
    $c.Add_MouseMove({
        if ($script:dragOffset) {
            $p = [System.Windows.Forms.Cursor]::Position
            $script:formRef.Location = New-Object System.Drawing.Point(
                ($script:dragFormLoc.X + $p.X - $script:dragOffset.X),
                ($script:dragFormLoc.Y + $p.Y - $script:dragOffset.Y))
        }
    })
    $c.Add_MouseUp({ $script:dragOffset = $null })
}

# 双击暂停/继续
$togglePause = {
    $script:Paused = -not $script:Paused
    if ($script:Paused) { $miPause.Text = '继续'; $lblStatus.Text = '已暂停（双击继续）' }
    else { $miPause.Text = '暂停'; $lblStatus.Text = '识别中' }
}
$miPause.Add_Click($togglePause)
$lblAnswer.Add_DoubleClick($togglePause)
$lblStatus.Add_DoubleClick($togglePause)

# 框选区域（右键菜单和右上角小方框共用）
function Select-Region {
    $form.Hide()
    Start-Sleep -Milliseconds 250
    $sel = New-Object System.Windows.Forms.Form
    $sel.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::None
    $sel.WindowState = [System.Windows.Forms.FormWindowState]::Maximized
    $sel.TopMost = $true
    $sel.Opacity = 0.22
    $sel.BackColor = [System.Drawing.Color]::Black
    $sel.Cursor = [System.Windows.Forms.Cursors]::Cross
    $sel.ShowInTaskbar = $false
    $script:selForm = $sel
    $script:selStart = $null
    $script:selRect = New-Object System.Drawing.Rectangle

    $sel.Add_MouseDown({ $script:selStart = $_.Location; $script:selRect = New-Object System.Drawing.Rectangle($_.X, $_.Y, 0, 0) })
    $sel.Add_MouseMove({
        if ($script:selStart) {
            $script:selRect = New-Object System.Drawing.Rectangle(
                [Math]::Min($script:selStart.X, $_.X),
                [Math]::Min($script:selStart.Y, $_.Y),
                [Math]::Abs($_.X - $script:selStart.X),
                [Math]::Abs($_.Y - $script:selStart.Y))
            $script:selForm.Invalidate()
        }
    })
    $sel.Add_Paint({
        if ($script:selRect -and $script:selRect.Width -gt 0) {
            $g = $_.Graphics
            $brush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(35, 120, 150, 120))
            $g.FillRectangle($brush, $script:selRect)
            $brush.Dispose()
            $pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(160, 200, 160), 2)
            $g.DrawRectangle($pen, $script:selRect)
            $pen.Dispose()
        }
    })
    $sel.Add_MouseUp({
        $p1 = $script:selStart
        $p2 = $_.Location
        $x = [Math]::Min($p1.X, $p2.X); $y = [Math]::Min($p1.Y, $p2.Y)
        $w = [Math]::Abs($p2.X - $p1.X); $h = [Math]::Abs($p2.Y - $p1.Y)
        $script:selForm.Close()
        if ($w -gt 40 -and $h -gt 20) {
            $script:Region = @{ X = $x; Y = $y; W = $w; H = $h }
            $script:Region | ConvertTo-Json | Set-Content $script:ConfigPath -Encoding UTF8
            $lblStatus.Text = '区域 ' + $w + '×' + $h
        }
    })
    $sel.Add_KeyDown({ if ($_.KeyCode -eq 'Escape') { $script:selForm.Close() } })
    [void]$sel.ShowDialog()
    $form.Show()
    $form.Activate()
    try { $form.BeginInvoke([Action]{ Do-Recognize }) | Out-Null } catch {}
}

$miSelect.Add_Click({ Select-Region })
$btnSelect.Add_Click({ Select-Region })

function Do-Recognize {
    if ($script:Paused -or $script:Busy) { return }
    $script:Busy = $true
    try {
        $r = $script:Region
        $img = Capture-Region $r.X $r.Y $r.W $r.H
        $text = Get-OcrText $img
        $hit = Find-Answer $text
        if ($hit) {
            $letter = $hit.Item.A
            $optText = ''
            if ($letter -and $hit.Item.O) {
                $idx = 'ABCDEFGH'.IndexOf($letter)
                if ($idx -ge 0 -and $idx -lt $hit.Item.O.Count) { $optText = $hit.Item.O[$idx] }
            }
            if ($letter) {
                $lblAnswer.Text = '答案：' + $letter + $(if ($optText) { '、' + $optText } else { '' })
            } else {
                $lblAnswer.Text = '此题暂无答案'
            }
            $lblAnswer.ForeColor = [System.Drawing.Color]::FromArgb(178, 184, 170)
            $lblStatus.Text = $hit.Item.P + ' · ' + [Math]::Round($hit.Score * 100) + '%'
        } else {
            $lblAnswer.Text = '未识别到题目'
            $lblAnswer.ForeColor = [System.Drawing.Color]::FromArgb(150, 140, 110)
            $lblStatus.Text = '右键可框选识别区域'
        }
    } catch {
        $lblStatus.Text = '识别出错'
    } finally {
        $script:Busy = $false
    }
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 1800
$timer.Add_Tick({
    if (-not $script:Busy -and -not $script:Paused) {
        $script:formRef.BeginInvoke([Action]{ Do-Recognize }) | Out-Null
    }
})
$timer.Start()

$form.Add_Shown({
    $lblStatus.Text = '识别中'
    $form.BeginInvoke([Action]{ Do-Recognize }) | Out-Null
})

[System.Windows.Forms.Application]::Run($form)
